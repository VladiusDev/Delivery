package com.shels.delivery;

public class Constants {

    // Preference
    public static final String PREFERENCE_USER = "pref_username";
    public static final String PREFERENCE_USER_PASSWORD = "pref_password";
    public static final String PREFERENCE_USER_PROFILE = "pref_user_profile";
    public static final String PREFERENCE_USER_ID = "pref_user_id";
    public static final String PREFERENCE_USER_AUTH_SUCCESS= "pref_auth_success";

    // Json fields
    public static final String JSON_FIELD_USER = "user";
    public static final String JSON_FIELD_USER_ID = "id";
    public static final String JSON_FIELD_USER_PROFILE = "profile";
    public static final String JSON_FIELD_DATA = "data";
}
