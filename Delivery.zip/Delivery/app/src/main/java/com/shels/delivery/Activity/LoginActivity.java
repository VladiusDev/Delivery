package com.shels.delivery.Activity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import com.shels.delivery.Constants;
import com.shels.delivery.DialogFactory;
import com.shels.delivery.JsonUtils.JsonParser1C;
import com.shels.delivery.R;
import com.shels.delivery.WebService.WebService1C;

import br.com.simplepass.loadingbutton.customViews.CircularProgressButton;

public class LoginActivity extends AppCompatActivity {

        private CircularProgressButton btn_auth;
    private EditText edt_password;
    private EditText edt_login;
    private Context context;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        context = this;

        // Views
        btn_auth = findViewById(R.id.btn_auth);
        edt_login = findViewById(R.id.edt_login);
        edt_password = findViewById(R.id.edt_password);

        // Listeners
        btn_auth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Save username and password to preference
                preferences.edit().putString(Constants.PREFERENCE_USER, edt_login.getText().toString()).apply();
                preferences.edit().putString(Constants.PREFERENCE_USER_PASSWORD, edt_password.getText().toString()).apply();

                new AuthorizationTask().execute();
            }
        });

        // Show saved username
        if (preferences.contains(Constants.PREFERENCE_USER)){
            edt_login.setText(preferences.getString(Constants.PREFERENCE_USER, ""));
        }
    }

    private class AuthorizationTask extends AsyncTask<Void, Void, ContentValues>{
        @Override
        protected ContentValues doInBackground(Void... voids) {
             return WebService1C.sendRequest(WebService1C.SOAP_METHOD_GET_USER_INFO, getApplicationContext());
        }

        @Override
        protected void onPreExecute() {
            btn_auth.startAnimation();
        }

        @Override
        protected void onPostExecute(ContentValues contentValues) {
            btn_auth.revertAnimation();

           if ((Boolean) contentValues.get("authorization") == true) {
                // Get user info from json answer
                ContentValues userInfo = JsonParser1C.getUserInfo(contentValues.get("result").toString());

                // Save user info to preference
                preferences.edit().putBoolean(Constants.PREFERENCE_USER_AUTH_SUCCESS, true).apply();
                preferences.edit().putString(Constants.PREFERENCE_USER_PROFILE, userInfo.get(Constants.JSON_FIELD_USER_PROFILE).toString()).apply();
                preferences.edit().putString(Constants.PREFERENCE_USER_ID, userInfo.get(Constants.JSON_FIELD_USER_ID).toString()).apply();

                // Open main activity
               Intent intent = new Intent(getApplicationContext(), DocumentsActivity.class);
               startActivity(intent);
           }else{
                DialogFactory.showAlertDialog(context, contentValues.get("message").toString(), context.getString(R.string.check_error_authorization));
           }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        btn_auth.dispose();
    }
}
