package com.shels.delivery.JsonUtils;

import android.content.ContentValues;
import android.os.AsyncTask;

import com.shels.delivery.Constants;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

public class JsonParser1C {

    public static ContentValues getUserInfo(String jsonText){
        try {
            return new GetUserInfoTask().execute(jsonText).get();
        } catch (ExecutionException e) {
            return null;
        } catch (InterruptedException e) {
            return null;
        }
    }

    public static Boolean getJsonResult(String jsonResult){
        if (!jsonResult.isEmpty()) {
            JSONObject jsonObject;

            try {
                jsonObject = new JSONObject(jsonResult);
            } catch (JSONException e) {
                return false;
            }

            if (jsonObject != null) {
                try {
                    Boolean result = jsonObject.getBoolean("result");

                    return result;
                } catch (JSONException e) {
                    return false;
                }
            }
        }

        return false;
    }

    private static class GetUserInfoTask extends AsyncTask<String, Void, ContentValues>{
        @Override
        protected ContentValues doInBackground(String... strings) {
            ContentValues result = new ContentValues();

            try {
                JSONObject jsonObject = new JSONObject(strings[0]);
                JSONObject data = jsonObject.getJSONObject(Constants.JSON_FIELD_DATA);

                result.put(Constants.JSON_FIELD_USER_ID, data.getString(Constants.JSON_FIELD_USER_ID));
                result.put(Constants.JSON_FIELD_USER, data.getString(Constants.JSON_FIELD_USER));
                result.put(Constants.JSON_FIELD_USER_PROFILE, data.getString(Constants.JSON_FIELD_USER_PROFILE));

                return result;
            } catch (JSONException e) {
                return result;
            }
        }
    }
}
